package user;

import java.util.Iterator;

public interface Fanatic extends User{
	
	public Iterator<String> getFanaticisms();
}
