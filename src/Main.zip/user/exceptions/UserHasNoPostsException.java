package user.exceptions;

public class UserHasNoPostsException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2217283444498112887L;
	
	public UserHasNoPostsException() {
		super();
	}
}
