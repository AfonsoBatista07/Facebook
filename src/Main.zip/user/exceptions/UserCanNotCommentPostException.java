package user.exceptions;

public class UserCanNotCommentPostException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 112218804686830108L;
	
	public UserCanNotCommentPostException() {
		super();
	}
	
}
