package system.exceptions;

public class NoKingPopularPostException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public NoKingPopularPostException() {
		super();
	}
}
