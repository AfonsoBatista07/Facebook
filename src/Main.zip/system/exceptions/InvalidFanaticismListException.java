package system.exceptions;

public class InvalidFanaticismListException  extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4730950725835496032L;
	public InvalidFanaticismListException() {
		super();
	}
}
