package system.exceptions;

public class InvalidNumberOfPostsException extends RuntimeException {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 970572607340229809L;

	public InvalidNumberOfPostsException() {
		super();
	}
}
