package system.exceptions;

public class InvalidHashtagsListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 286286651199649578L;
	
	public InvalidHashtagsListException() {
		super();
	}
}
