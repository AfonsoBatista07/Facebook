package system.exceptions;

public class NoPostsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7266553819067031902L;
	public NoPostsException() {
		super();
	}

}
