package system.exceptions;

public class UserCanNotBeTheSameException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 137270238836618845L;

	public UserCanNotBeTheSameException() {
		super();
	}
}
