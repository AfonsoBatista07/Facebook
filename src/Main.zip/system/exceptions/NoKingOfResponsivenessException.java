package system.exceptions;

public class NoKingOfResponsivenessException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3957434001609057602L;
	public NoKingOfResponsivenessException() {
		super();
	}
}
