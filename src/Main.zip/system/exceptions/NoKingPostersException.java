package system.exceptions;

public class NoKingPostersException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7559390067032292620L;
	public NoKingPostersException() {
		super();
	}
}
