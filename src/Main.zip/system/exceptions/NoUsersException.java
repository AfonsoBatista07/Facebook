package system.exceptions;

public class NoUsersException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2124299706527122145L;
	public NoUsersException() {
		super();
	}

}
