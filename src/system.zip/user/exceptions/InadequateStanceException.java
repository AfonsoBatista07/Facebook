package user.exceptions;

public class InadequateStanceException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6833999717529530423L;
	public InadequateStanceException() {
		super();
	}
}
