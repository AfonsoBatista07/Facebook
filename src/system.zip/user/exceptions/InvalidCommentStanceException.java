package user.exceptions;

public class InvalidCommentStanceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -683399971752953043L;
	public InvalidCommentStanceException() {
		super();
	}
}
