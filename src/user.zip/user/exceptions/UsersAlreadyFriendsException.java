package user.exceptions;

public class UsersAlreadyFriendsException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5565779026114868383L;
	
	public UsersAlreadyFriendsException() {
        super();
    }
}